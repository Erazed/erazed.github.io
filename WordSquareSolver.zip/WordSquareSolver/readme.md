# About

Generates all possible word squares with supplied arguments.

These take the form of `<n> <characters>` 

ie: `'4 aaccdeeeemmnnnoo'`

## Running the app
### Prerequisites
- JDK 11
- Internet Access (maven central + gradle wrapper)

### Via gradle
`./gradlew run --args='4 aaccdeeeemmnnnoo'`

####note:
  
replace args with word square parameters
eg:

`'5 aaaeeeefhhmoonssrrrrttttw'`