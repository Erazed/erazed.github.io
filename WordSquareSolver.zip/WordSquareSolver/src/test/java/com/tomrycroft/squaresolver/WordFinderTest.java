package com.tomrycroft.squaresolver;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.contains;
import org.junit.jupiter.api.Test;

import java.util.Arrays;

public class WordFinderTest {

    @Test
    public void findsWordsOfCorrectLength() {
        var wordFinder = new WordFinder(Arrays.asList("1", "22", "333", "4444"));
        var found = wordFinder.findMatchingWords(3, "1223334444", "");

        assertThat(found, contains("333"));
    }

    @Test
    public void withPrefix() {
        var wordFinder = new WordFinder(Arrays.asList("1abc", "2abc", "3abc", "4abc"));
        var found = wordFinder.findMatchingWords(4, "1234abc", "3a");

        assertThat(found, contains("3abc"));
    }

    @Test
    public void withCorrectCharacters() {
        var wordFinder = new WordFinder(Arrays.asList("1abc", "2bcd", "3cde", "abcd", "dcba"));
        var found = wordFinder.findMatchingWords(4, "abcd", "");

        assertThat(found, contains("abcd", "dcba"));
    }

    @Test
    public void withCorrectNumberOfCharacters() {
        var wordFinder = new WordFinder(Arrays.asList("3333", "1122", "3333", "1223"));
        var found = wordFinder.findMatchingWords(4, "122333", "");

        assertThat(found, contains("1223"));
    }

}
