package com.tomrycroft.squaresolver;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

import java.util.Arrays;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.contains;

public class SquareFinderTest {

    // Tests against a constrained word list - so we actually find only the square we care about

    @Test
    public void solvesChallengeSolution1() throws Exception {
        WordFinder wordFinder = new WordFinder(Arrays.asList("moan", "once", "acme", "need"));
        SquareFinder squareFinder = new SquareFinder(wordFinder, 4, "aaccdeeeemmnnnoo");
        assertThat(squareFinder.findSquares().get(0), contains("moan", "once", "acme", "need"));
    }

    @Test
    public void solvesChallengeSolution2() throws Exception {
        WordFinder wordFinder = new WordFinder(Arrays.asList("feast", "earth", "armor", "stone", "threw"));
        SquareFinder squareFinder = new SquareFinder(wordFinder, 5, "aaaeeeefhhmoonssrrrrttttw");
        assertThat(squareFinder.findSquares().get(0), contains("feast", "earth", "armor", "stone", "threw"));
    }

    @Test
    public void solvesChallengeSolution3() throws Exception {
        WordFinder wordFinder = new WordFinder(Arrays.asList("heart", "ember", "above", "revue", "trees"));
        SquareFinder squareFinder = new SquareFinder(wordFinder, 5, "aabbeeeeeeeehmosrrrruttvv");
        assertThat(squareFinder.findSquares().get(0), contains("heart", "ember", "above", "revue", "trees"));
    }

    @Test
    public void solvesChallengeSolution4() throws Exception {
        WordFinder wordFinder = new WordFinder(Arrays.asList("bravado", "renamed", "analogy", "valuers", "amoebas", "degrade", "odyssey"));
        SquareFinder squareFinder = new SquareFinder(wordFinder, 7, "aaaaaaaaabbeeeeeeedddddggmmlloooonnssssrrrruvvyyy");
        assertThat(squareFinder.findSquares().get(0), contains("bravado", "renamed", "analogy", "valuers", "amoebas", "degrade", "odyssey"));
    }
}
