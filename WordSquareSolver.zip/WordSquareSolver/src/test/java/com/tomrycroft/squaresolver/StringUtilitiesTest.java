package com.tomrycroft.squaresolver;

import org.junit.jupiter.api.Test;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.is;

public class StringUtilitiesTest {

    @Test
    public void seperateOnNewLine_splitsStringsOnNewLines() {
        String string = "test\\nstuff\\nmore stuff";
        assertThat(StringUtilities.seperateOnNewLine(string), contains("test", "stuff", "more stuff"));
    }

    @Test
    public void removeWordFromString() {
        String string = "so1me2 stri3ng";
        assertThat(StringUtilities.removeWordFromString("321", string), is("some string"));
    }
}
