package com.tomrycroft.squaresolver;

import java.util.Arrays;
import java.util.List;

public class StringUtilities {

    public static List<String> seperateOnNewLine(String string) {
        return Arrays.asList(string.split("\\R"));
    }

    public static String removeWordFromString(String word, String string) {
        StringBuilder builder = new StringBuilder(string);
        word.chars().forEach(c -> {
            builder.deleteCharAt(builder.indexOf(String.valueOf((char) c)));
        });
        return builder.toString();
    }
}
