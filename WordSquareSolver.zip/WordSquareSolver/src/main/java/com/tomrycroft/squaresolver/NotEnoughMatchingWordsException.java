package com.tomrycroft.squaresolver;

public class NotEnoughMatchingWordsException  extends Exception {
    public NotEnoughMatchingWordsException(String errorMessage) {
        super(errorMessage);
    }
}
