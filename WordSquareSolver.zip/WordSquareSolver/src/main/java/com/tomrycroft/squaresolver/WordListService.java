package com.tomrycroft.squaresolver;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.Collections;
import java.util.List;

public class WordListService {

    public List<String> getWordList() {
        try {
            var client = HttpClient.newHttpClient();
            var request = HttpRequest.newBuilder().uri(URI.create("http://norvig.com/ngrams/enable1.txt")).build();
            var response = client.send(request, HttpResponse.BodyHandlers.ofString());
            return StringUtilities.seperateOnNewLine(response.body());
        } catch (IOException | InterruptedException e) {
            // On failure return empty list, right now we don't necessarily care to handle the error
            return Collections.emptyList();
        }
    }
}
