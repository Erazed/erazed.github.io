package com.tomrycroft.squaresolver;

import java.util.List;
import java.util.stream.Collectors;

import static org.apache.commons.lang3.StringUtils.containsOnly;
import static org.apache.commons.lang3.StringUtils.countMatches;

public class WordFinder {

    private List<String> validWords;

    public WordFinder(List<String> validWords) {
        this.validWords = validWords;
    }

    public List<String> findMatchingWords(int wordLength, String allowedCharacters, String prefix) {
        // Chop the list down via a series of filters till we get precisely the words that will fit

        return validWords.stream()
                .filter(s -> s.length() == wordLength)
                .filter(s -> s.startsWith(prefix))
                .filter(s -> containsOnly(s, allowedCharacters))
                .filter(s ->
                    s.chars().distinct().allMatch(c -> countMatches(s, (char) c) <= countMatches(allowedCharacters, (char) c))
                ).collect(Collectors.toList());
    }
}
