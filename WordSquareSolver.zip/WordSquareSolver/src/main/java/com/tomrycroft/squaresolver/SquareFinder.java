package com.tomrycroft.squaresolver;

import java.util.LinkedList;
import java.util.List;

public class SquareFinder {

    private int wordLength;
    private String allowedCharacters;
    private WordFinder wordFinder;

    public SquareFinder(WordFinder wordFinder, int wordLength, String allowedCharacters) {
        super();
        this.wordFinder = wordFinder;
        this.wordLength = wordLength;
        this.allowedCharacters = allowedCharacters;
    }

    public List<List<String>> findSquares() throws NotEnoughMatchingWordsException {
        var firstPassWordList = wordFinder.findMatchingWords(wordLength, allowedCharacters, "");

        if(firstPassWordList.size() < wordLength) {
            throw new NotEnoughMatchingWordsException(String.format("%d words found matching %s, %d required.", firstPassWordList.size(), allowedCharacters, wordLength));
        }

        List<List<String>> squareCandidates = new LinkedList<>();

        // Get the initial seed words
        for(var word : firstPassWordList) {
            var list = new LinkedList<String>();
            list.add(word);
            squareCandidates.add(list);
        }

        // Brute force the squares that work, pruning dead ends
        // Not particularly fast or pretty, but gets the job done
        // Few "obvious" optimisations not realised due to time constraints:
        // - utilising the odd numbers of digits on diagonal to prune choices quicker
        // - distributing the search across more threads
        // - cache values for prefixes + constrained get allowed characters to speed those bits up

        for(int i = 0; i < wordLength - 1; i++) {
            System.out.println("Generation: " + (i + 1) + " Candidates: " + squareCandidates.size());
            squareCandidates = iterateCandidates(squareCandidates);
        }

        return squareCandidates;
    }

    // Get next level of candidates
    private List<List<String>> iterateCandidates(List<List<String>> squareCandidates) {
        List<List<String>> nextGeneration = new LinkedList<>();

        // Get next possible set of words for existing square candidate list
        squareCandidates.forEach(squareCandidate -> {
            String prefix = getPrefix(squareCandidate);
            String newAllowedCharacters = getAllowedCharacters(squareCandidate);

            var wordList = wordFinder.findMatchingWords(wordLength, newAllowedCharacters, prefix);

            // If our current list of words has more options add each as a candidate
            // If it doesn't then its a dead end and can be ignored
            wordList.forEach(word -> {
                List<String> newCandidate = new LinkedList<>(squareCandidate);
                newCandidate.add(word);
                nextGeneration.add(newCandidate);
            });
        });

        return nextGeneration;
    }

    // Get remaining characters from the allowed set based on current cadidate words
    private String getAllowedCharacters(List<String> squareCandidate) {
        String newAllowedCharacters = allowedCharacters;

        for(var word : squareCandidate) {
            newAllowedCharacters = StringUtilities.removeWordFromString(word, allowedCharacters);
        }

        return newAllowedCharacters;
    }

    // Get the prefix for the next word based on current candidate words for square
    private String getPrefix(List<String> squareCandidate) {
        String prefix = "";
        for(var word : squareCandidate) {
            prefix += word.charAt(squareCandidate.size());
        }
        return prefix;
    }
}
