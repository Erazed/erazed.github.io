package com.tomrycroft.squaresolver;

import java.io.IOException;

public class WordSquareSolverApplication {

    public static void main(String[] args) throws IOException, InterruptedException, NotEnoughMatchingWordsException {

        WordFinder finder = new WordFinder(new WordListService().getWordList());

        // assuming user competence :) - given time more guarding of inputs
        var squares = new SquareFinder(finder, Integer.parseInt(args[0]), args[1]).findSquares();
        System.out.println(squares);
    }
}
